package practice1;

public class myRed {

}
