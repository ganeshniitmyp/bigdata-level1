import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<myKey, myValue, Text, Text> {
	
	public void map(myKey inpK, myValue inpV, Context c) throws IOException, InterruptedException{
		int minAmt = c.getConfiguration().getInt("Amount", 30);
		int amt = inpV.getAmt();
		if(amt>minAmt){
			c.write(new Text(inpK.getname()+" "+inpK.getid()), new Text(Double.toString(inpV.getAmt())));
		}
	}

}
