package mapsidejoin2;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class mapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	HashMap<String, String> hm= new HashMap<>();
	public void setup(Context c) throws IOException{
		Path[] allFiles = DistributedCache.getLocalCacheFiles(c.getConfiguration());		
		for(Path eachFile : allFiles){
			if(eachFile.getName().equals("student.txt")){
				FileReader fr = new FileReader(eachFile.toString());
				BufferedReader br = new BufferedReader(fr);
				String line =br.readLine();
				while(line != null){
					String[] eachVal = line.split(" ");
					String sid = eachVal[0];
					String sname = eachVal[1];
					hm.put(sid, sname);
					line=br.readLine();
				}
				br.close();
			}
			if (hm.isEmpty()) 
			{
				throw new IOException("Unable To Load file1");
			}
		}
	}
	
	public void map(LongWritable mInpKey, Text mInpVal, Context c) throws IOException, InterruptedException{
		String line = mInpVal.toString();
		String eachVal[] = line.split(" ");
		String sid=eachVal[0];
		String marks= eachVal[1];
		String sname = hm.get(sid);
		
		Text mOutKey = new Text("Student Id : " +sid +" Student Name : " +sname);
		IntWritable mOutVal = new IntWritable(Integer.parseInt(marks));
		
		c.write(mOutKey, mOutVal);
		
	} 
	

}
