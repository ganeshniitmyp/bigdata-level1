package mapsidejoin;


import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class map6 extends Mapper<key, value, Text, DoubleWritable>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		Double minamt = (double) c.getConfiguration().getInt("Amount", 160);
		Double amt = inpv.getAmt();
 	   if(amt>minamt)
 	   {
 		    c.write(new Text(inpk.getid()),new DoubleWritable(inpv.getAmt()));
 	   }
    }
}

/*int minAmt = c.getConfiguration().getInt("Amount", 30);
		int amt = inpV.getAmt();
		if(amt>minAmt){
			c.write(new Text(inpK.getname()+" "+inpK.getid()), new Text(Double.toString(inpV.getAmt())));
		}
	}

}*/