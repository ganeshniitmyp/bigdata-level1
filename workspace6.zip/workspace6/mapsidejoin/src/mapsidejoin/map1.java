package mapsidejoin;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class map1 extends Mapper<LongWritable, Text, Text, IntWritable> {
	HashMap<String, String> hm= new HashMap<>();
	public void setup(Context c) throws IOException{
		Path[] allFiles = DistributedCache.getLocalCacheFiles(c.getConfiguration());		
		for(Path eachFile : allFiles){
			if(eachFile.getName().equals("DeptTasKdata.dat")){
				FileReader fr = new FileReader(eachFile.toString());
				BufferedReader br = new BufferedReader(fr);
				String line =br.readLine();
				while(line != null){
					String[] eachVal = line.split(",");
					String depid = eachVal[0];
					String depname = eachVal[1];
					hm.put(depid, depname);
					line=br.readLine();
				}
				br.close();
			}
			if (hm.isEmpty()) 
			{
				throw new IOException("Unable To Load file1");
			}
		}
	}
	
	public void map(LongWritable mInpKey, Text mInpVal, Context c) throws IOException, InterruptedException{
		String line = mInpVal.toString();
		String eachVal[] = line.split(",");
		String depid=eachVal[4];
		String salary= eachVal[2];
		String depname = hm.get(depid);
		
		Text mOutKey = new Text("Dep Id : " +depid +" Dep Name : " +depname);
		IntWritable mOutVal = new IntWritable(Integer.parseInt(salary));
		
		c.write(mOutKey, mOutVal);
		
	} 
	

}
