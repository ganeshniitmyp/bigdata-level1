package mapsidejoin;


import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class red1 extends Reducer<Text, IntWritable, Text, Text> {
	public void reduce(Text rInpKey, Iterable<IntWritable> rInpVal,Context c ) throws IOException, InterruptedException{
		int salary=0;
		for(IntWritable each: rInpVal){
			salary+= Integer.parseInt(each.toString());
		}
		c.write(rInpKey, new Text("Salary : " +salary));
	}

}
