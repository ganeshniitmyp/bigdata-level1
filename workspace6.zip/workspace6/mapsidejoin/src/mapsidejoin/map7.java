package mapsidejoin;


import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class map7 extends Mapper<key, value, Text, DoubleWritable>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		Double minamt = (double) c.getConfiguration().getInt("Lower", 175);
		Double maxamt = (double) c.getConfiguration().getInt("Upper", 200);
		Double amt = inpv.getAmt();
 	   if(amt>minamt && amt<maxamt)
 	   {
 		    c.write(new Text(inpk.getid()),new DoubleWritable(inpv.getAmt()));
 	   }
    }
}