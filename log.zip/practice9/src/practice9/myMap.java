package practice9;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMap extends Mapper<LongWritable,Text,Text,Text> {
	public void map(LongWritable mInpKey,Text mInpVal,Context con) throws IOException, InterruptedException{
		String inpVal = mInpVal.toString();
		String[] eachVal = inpVal.split(" ");
		Text mOutKey = new Text(eachVal[3]);
		Text mOutVal = new Text(inpVal);
		con.write(mOutKey, mOutVal);
		
		
	}

}
