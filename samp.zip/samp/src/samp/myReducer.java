package samp;

public class myReducer {

}
