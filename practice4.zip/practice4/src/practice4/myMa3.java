package practice4;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMa3 extends Mapper<LongWritable, Text, Text, DoubleWritable>{
	public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
		String value = inpv.toString();
		String eachval[] = value.split(",");
		String month[] = eachval[1].split("-");
 	   double val = Double.parseDouble(eachval[3]);
 	   	   Text outk = new Text(month[0]);
 		   DoubleWritable outv = new DoubleWritable(val);
 		   c.write(outk,outv);
 	 
    }
}
