package task5;


import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public  class myPar5  extends Partitioner< IntWritable,Text>
{

	@Override
	public int getPartition(IntWritable arg0, Text arg1, int arg2) {

int val=arg0.get();
if(val==1)
{
		return 0;
	}
else if(val==2)
{
	return 1;
}
else if(val==3)
{
	return 2;
}
else if(val==4)
{
	return 3;
}
else if(val==5)
{
	return 4;
}
else if(val==6)
{
	return 5;
}
else if(val==7)
{
	return 6;
}else if(val==8)
{
	return 7;
}
else if(val==9)
{
	return 8;
}
else if(val==10)
{
	return 9;
}
else if(val==11)
{
	return 10;
}
else 
{
	return 11;
}
	}

}
