package task1;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<MyKey, MyValue, Text, Text> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		Double minamt = (double) c.getConfiguration().getInt("Amount", 160);
		double amt = inpV.getAmt();
		if(amt>minamt){
			c.write(new Text(inpK.getid()), new Text(Double.toString(inpV.getAmt())));
		}
	}

}
