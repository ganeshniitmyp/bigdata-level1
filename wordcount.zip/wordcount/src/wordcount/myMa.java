package wordcount;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMa extends Mapper<LongWritable,Text, Text,IntWritable>{
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException
	{
		IntWritable i =new IntWritable(1);
		String value=inpv.toString();
		Text t=new Text();
		StringTokenizer s=new StringTokenizer(value);
		while(s.hasMoreTokens())
		{
			t.set(s.nextToken());
			c.write(t, i);
		}
	}
	}

