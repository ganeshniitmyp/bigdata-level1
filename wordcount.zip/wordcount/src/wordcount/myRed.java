package wordcount;


import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myRed extends Reducer<Text,IntWritable,Text,IntWritable> {
	public void reduce(Text inpk,Iterable<IntWritable> inpv,Context c) throws IOException,InterruptedException
	{
int sum=0;
for(IntWritable value:inpv)
{
	sum+=value.get();
}
c.write(inpk, new IntWritable(sum));
    }
}
